package Test_1230_1;

public class Coding_10_1 {
	static int money = 10000;
	static int minus = 0;
	static int plus = 0;
}
