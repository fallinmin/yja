package Test_1230_1;

public class Coding_9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Play movie = new Play();
		movie.mo();
		
	}

}

