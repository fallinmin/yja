//package sook;
//
//public class _18 {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		for (int i = 0; i < 5; i++) {
//			  // j: ��
//			  for (int j = 0; j < 5; j++) {
//			    if (5 - j == i + 1)
//			      System.out.print("* ");
//			    else
//			      System.out.print("  ");
//			  }
//			  System.out.println();
//			}
//	}
//
//}
