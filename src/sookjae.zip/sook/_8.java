package sook;

import java.util.Scanner;

public class _8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("�����Է�");
		Scanner sc = new Scanner(System.in);
		
		int a = sc.nextInt();
		
		int b = a%10;
		
		
		
		System.out.println(e);
		
	}

}
