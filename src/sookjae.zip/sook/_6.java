package sook;

import java.util.Scanner;

public class _6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int key = sc.nextInt();
		int sigan = sc.nextInt();
		int pay = key*sigan;
		
		System.out.println(pay);
	
		
	}

}
