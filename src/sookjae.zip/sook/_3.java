package sook;

public class _3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  String name = "ȫ�浿";
	        int studentNumber = 20101819;
	        double tall = 1.70;
	        boolean isMale = true;
	        // ���ڿ� ���
	        System.out.println("�̸�: " + name);
	        System.out.println("�й�: " + studentNumber);
	        System.out.println("����: " + tall + "m");
	        System.out.println("�����ΰ���?" + isMale);
	}

}
