package sook;

import java.util.Scanner;

public class _20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int n = sc.nextInt();
		String str = sc.next();
		for (int i = 0; i < str.length(); i++) {
		    switch (str.charAt(i)) {
		    case 'a':
		    case 'e':
		        ...
		        break;
		    default:
		        ...
		        break;
		    }
		}
	}

}
