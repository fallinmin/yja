package Test_1230_1;

public class Coding_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int val_1 = 83;
		double val_2 = 2.0;
		
		double val_3 = (double)val_1/val_2;
		System.out.println(val_3);
	}

}
