package Test_1230_1;
//�̿ϼ� �߸𸣰���
public class Coding_9_1 {
	static String movie_name ="";
	static String movie_RunTime ="";
	static String movie_actor ="";
	public String getMovie_RunTime() {
		return movie_RunTime;
	}
	public void setMovie_RunTime(String movie_RunTime) {
		this.movie_RunTime = "1�ð� 30��";
	}
	public String getMovie_actor() {
		return movie_actor;
	}
	public void setMovie_actor(String movie_actor) {
		this.movie_actor = movie_actor;
	}
	public String getMovie_name() {
		return movie_name;
	}
	public void setMovie_name(String movie_name) {
		this.movie_name = "Ʈ��������";
	}

	
}
class Movie_info extends Coding_9_1{

}

class Movie_actor extends Movie_info{

	@Override
	public void setMovie_actor(String movie_actor) {
		// TODO Auto-generated method stub
		super.setMovie_actor("�ް� ����");
	}
	
}

class Play extends Movie_actor{
	
	public static void mo() {
		Coding_9_1 movie = new Coding_9_1();
		System.out.println(movie_name);
		System.out.println(movie_RunTime);
		System.out.println(movie_actor);
	}

}