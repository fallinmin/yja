package Test_1230_1;

public class Coding_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i =1;i<=9;i++) {
			for(int j =1;j<=9;j++) {
				System.out.println(i+"X"+j+"="+i*j);
			}
		}
	}

}
