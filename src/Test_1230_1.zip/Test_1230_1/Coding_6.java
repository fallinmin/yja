package Test_1230_1;

public class Coding_6 {
//�̿ϼ� �߸𸣰���
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String string = "9B768C";
		String[] a = new String[string.length()];
		
		for(int i =0;i<=string.length();i++) {
			a[i] = string.substring(i,i+1);
		}
	}

}
